import type { NextConfig } from "next";

// For GitHub Pages project sites (https://USERNAME.github.io/REPO_NAME/),
// set basePath to "/REPO_NAME". For root domain or local dev, leave it empty.
const repoName = process.env.GITHUB_REPOSITORY?.split("/")[1] ?? "";
const isGHPages = process.env.GITHUB_ACTIONS === "true" && repoName;

const nextConfig: NextConfig = {
  output: "export",
  basePath: isGHPages ? `/${repoName}` : "",
  images: { unoptimized: true },
  trailingSlash: true,
  typescript: { ignoreBuildErrors: true },
  reactStrictMode: false,
};

export default nextConfig;
